import os
import pytesseract

TESSERACT_CONFIG = {
    'eng': r'--oem 3 --psm 3',
    'mar': r'--oem 3 --psm 3',
    'jpn': r'--oem 3 --psm 1',
    'default': r'--oem 3 --psm 3'
}

pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'
os.environ['TESSDATA_PREFIX'] = '/usr/share/tesseract-ocr/5/tessdata/'
