import fitz
import re
import statistics
import numpy as np
import cv2
from .ocr_handler import OcrHandler


class LayoutParser:
    def __init__(self, ocr_handler_instance):
        self.ocr_handler = ocr_handler_instance

    def _get_digital_font_data(self, page):
        font_sizes = []
        font_names = []
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if span.get('size', 0) > 0:
                        font_sizes.append(span['size'])
                    font_name = span.get('font', '')
                    font_names.append(font_name.lower())
        return font_sizes, font_names

    def _infer_digital_block_features(self, block_dict_from_pymu, page_width, page_height, avg_page_font_size,
                                      max_page_font_size):
        block_text = ""
        font_sizes = []
        font_names = []

        for line in block_dict_from_pymu.get("lines", []):
            for span in line.get("spans", []):
                block_text += span.get('text', '') + " "
                if span.get('size', 0) > 0:
                    font_sizes.append(span['size'])
                font_name = span.get('font', '')
                font_names.append(font_name.lower())

        block_text = re.sub(r'\s+', ' ', block_text).strip()
        if not block_text:
            return None

        avg_font_size_block = statistics.mean(font_sizes) if font_sizes else 0.0
        is_bold_block = any(f in name for name in font_names for f in ['bold', 'heavy', 'black', 'demi'])
        is_italic_block = any(f in name for name in font_names for f in ['italic', 'oblique'])

        first_char = block_text.lstrip()[0] if block_text.lstrip() else ''

        bbox = block_dict_from_pymu.get('bbox', (0, 0, 0, 0))
        x0_norm = bbox[0] / page_width if page_width > 0 else 0.0
        height_norm = (bbox[3] - bbox[1]) / page_height if page_height > 0 else 0.0

        block_center_x_norm = ((bbox[0] + bbox[2]) / 2) / page_width
        is_centered = float(abs(block_center_x_norm - 0.5) < 0.15)

        features_dict = {
            'font_size': avg_font_size_block,
            'is_bold': float(is_bold_block),
            'is_italic': float(is_italic_block),
            'is_centered': is_centered,
            'char_count': float(len(block_text)),
            'x0_norm': x0_norm,
            'height_norm': height_norm,
            'has_leading_digit_or_bullet': float(
                first_char.isdigit() or first_char in ['•', '●', '☆', '-', '*']),
            'relative_font_size_to_page_avg': avg_font_size_block / avg_page_font_size if avg_page_font_size > 0 else 1.0,
            'relative_font_size_to_page_max': avg_font_size_block / max_page_font_size if max_page_font_size > 0 else 1.0
        }

        return {
            'text': block_text,
            'bbox': bbox,
            'page_num': None,
            'block_id': None,
            'features': features_dict
        }

    def extract_text_blocks_with_features(self, pdf_path, lang='eng', max_pages=50):
        doc = fitz.open(pdf_path)
        all_feature_blocks = []

        for page_num, page in enumerate(doc):
            if page_num >= max_pages:
                break

            current_page_blocks_with_features = []

            digital_text_data = page.get_text("dict")["blocks"]
            filtered_digital_blocks = []
            for b in digital_text_data:
                if "lines" in b:
                    block_content = " ".join([span.get('text', '') for line in b["lines"] for span in line["spans"]])
                    if block_content.strip():
                        filtered_digital_blocks.append(b)

            if len(filtered_digital_blocks) > 0:
                page_digital_font_sizes, _ = self._get_digital_font_data(page)
                page_avg_font_size_digital = statistics.mean(
                    page_digital_font_sizes) if page_digital_font_sizes else 12.0
                page_max_font_size_digital = max(page_digital_font_sizes) if page_digital_font_sizes else 24.0

                page_width, page_height = (page.rect.width or 1), (page.rect.height or 1)

                for block_idx, block_dict in enumerate(filtered_digital_blocks):
                    features_block = self._infer_digital_block_features(
                        block_dict, page_width, page_height,
                        page_avg_font_size_digital, page_max_font_size_digital
                    )
                    if features_block:
                        features_block['page_num'] = page_num + 1
                        features_block['block_id'] = f"p{page_num + 1}_b{block_idx}"
                        current_page_blocks_with_features.append(features_block)

            if not current_page_blocks_with_features or True:
                pix = page.get_pixmap(dpi=300)
                img_array = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
                if pix.n == 4:
                    img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)

                processed_image = self.ocr_handler.preprocess(img_array)
                ocr_blocks_raw = self.ocr_handler.ocr_image_to_blocks(processed_image, lang=lang)

                page_ocr_font_sizes = [b.get('font_size', 0.0) for b in ocr_blocks_raw if b.get('font_size', 0.0) > 0]
                page_avg_font_size_ocr = statistics.mean(page_ocr_font_sizes) if page_ocr_font_sizes else 12.0
                page_max_font_size_ocr = max(page_ocr_font_sizes) if page_ocr_font_sizes else 24.0

                for block_idx, block in enumerate(ocr_blocks_raw):
                    features_dict = {
                        'font_size': block.get('font_size', 0.0),
                        'is_bold': block.get('is_bold', 0.0),
                        'is_italic': block.get('is_italic', 0.0),
                        'is_centered': block.get('is_centered', 0.0),
                        'char_count': float(len(block.get('text', ''))),
                        'x0_norm': block.get('x0_norm', 0.0),
                        'height_norm': block.get('height_norm', 0.0),
                        'has_leading_digit_or_bullet': block.get('has_leading_digit_or_bullet', 0.0),
                        'relative_font_size_to_page_avg': block.get('font_size',
                                                                    0.0) / page_avg_font_size_ocr if page_avg_font_size_ocr > 0 else 1.0,
                        'relative_font_size_to_page_max': block.get('font_size',
                                                                    0.0) / page_max_font_size_ocr if page_max_font_size_ocr > 0 else 1.0
                    }

                    current_page_blocks_with_features.append({
                        'text': block.get('text', ''),
                        'bbox': block.get('bbox'),
                        'page_num': page_num + 1,
                        'block_id': f"p{page_num + 1}_b{block_idx}_ocr",
                        'features': features_dict
                    })

            all_feature_blocks.extend(current_page_blocks_with_features)

        doc.close()
        return all_feature_blocks
