import joblib
import pandas as pd
from app.utils.logger import get_logger

PIPELINE_PATH = "/app/models/hybrid_pipeline.joblib"
ENCODER_PATH = "/app/models/label_encoder.pkl"

class HeadingClassifier:
    def __init__(self):
        self.logger = get_logger()
        self.pipeline = None
        self.label_encoder = None
        try:
            self.pipeline = joblib.load(PIPELINE_PATH)
            self.label_encoder = joblib.load(ENCODER_PATH)
            self.logger.info("Successfully loaded hybrid model pipeline.")
        except Exception as e:
            self.logger.error(f"Error loading pipeline: {e}")

    def predict(self, blocks):
        if not self.pipeline or not self.label_encoder or not blocks:
            for block in blocks:
                block['level'] = 'Body'
            return blocks

        df_to_predict = pd.json_normalize(blocks)

        if 'text' not in df_to_predict.columns:
            df_to_predict['text'] = ''

        try:
            df_to_predict = df_to_predict.fillna(0)
            predictions_encoded = self.pipeline.predict(df_to_predict)
            predictions_decoded = self.label_encoder.inverse_transform(predictions_encoded)

            for i, block in enumerate(blocks):
                block['level'] = predictions_decoded[i]

        except Exception as e:
            self.logger.error(f"Could not predict blocks: {e}")
            for block in blocks:
                block['level'] = 'Body'

        return blocks
