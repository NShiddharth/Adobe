import re
from collections import Counter
import numpy as np


class Postprocessor:
    def __init__(self, classified_blocks):
        self.blocks = classified_blocks
        self.header_footer_texts = self._identify_headers_footers()

    def _identify_headers_footers(self):
        potential_hf_blocks = [b for b in self.blocks if b.get('level') == 'Body' and len(b['text'].split()) < 15]
        text_page_counts = {}
        for block in potential_hf_blocks:
            text = block['text'].strip()
            page = block.get('page_num')
            if text not in text_page_counts:
                text_page_counts[text] = set()
            text_page_counts[text].add(page)
        return {text for text, pages in text_page_counts.items() if len(pages) > 1}

    def find_title(self):
        best_candidate = {"text": "Untitled Document", "font_size": 0.0}
        h1_candidates_on_page1 = []
        for block in self.blocks:
            if block.get('page_num') == 1 and block.get('level') == 'H1':
                h1_candidates_on_page1.append(block)
        h1_candidates_on_page1.sort(key=lambda x: x.get('font_size', 0.0), reverse=True)
        for block in h1_candidates_on_page1:
            text = block['text'].strip()
            if not text or text.isdigit() or len(text) < 5 or \
                    "chapter" in text.lower() or "introduction" in text.lower() or "abstract" in text.lower():
                continue
            best_candidate['text'] = text
            best_candidate['font_size'] = block.get('font_size', 0.0)
            break
        cleaned_title = best_candidate['text'].replace("Title:", "").strip()
        if ":" in cleaned_title and len(
                cleaned_title.split(":", 1)[0].split()) < 3:
            cleaned_title = cleaned_title.split(":", 1)[1].strip()
        return cleaned_title

    def create_outline(self):
        headings = ['H1', 'H2', 'H3']
        final_outline = []
        seen_normalized_texts = set()
        document_title = self.find_title()
        for block in self.blocks:
            level = block.get('level')
            text = block['text'].strip()
            page = block.get('page_num')
            if level not in headings:
                continue
            if not text or text.isdigit() or len(text) < 3:
                continue
            if text in self.header_footer_texts:
                continue
            if text.lower() == document_title.lower():
                continue
            normalized_text = re.sub(r'\s+', ' ', text).lower()
            normalized_text = re.sub(r'^(chapter\s+\d+\.?\s*:?.*|section\s+\d+\.?\s*:?.*|―\s*|\s*―)$', '', normalized_text).strip()
            if normalized_text in seen_normalized_texts:
                continue
            seen_normalized_texts.add(normalized_text)
            final_outline.append({"level": level, "text": text, "page": page})
        return final_outline, document_title
