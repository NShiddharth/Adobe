# app/modules/ocr_handler.py
import pytesseract
import cv2
import numpy as np
import statistics
import traceback
from app.utils.config import TESSERACT_CONFIG

class OcrHandler:
    def preprocess(self, image_array):
        if len(image_array.shape) == 3:
            gray = cv2.cvtColor(image_array, cv2.COLOR_BGR2GRAY)
        else:
            gray = image_array
        _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        return thresh

    def ocr_image_to_blocks(self, image, lang='eng'):
        config_str = TESSERACT_CONFIG.get(lang, TESSERACT_CONFIG['default'])

        try:
            data = pytesseract.image_to_data(image, config=config_str, output_type=pytesseract.Output.DICT, lang=lang)

            blocks = []
            current_block_words_info = []

            prev_word_bottom_y = 0
            img_height, img_width = image.shape[:2]
            num_entries = len(data.get('level', []))

            for i in range(num_entries):
                level = data.get('level', [-1])[i]
                conf = data.get('conf', [-1])[i]
                word_text_raw = data.get('text', [''])[i]

                if level != 5 or not word_text_raw.strip() or int(conf) < 60:
                    if current_block_words_info:
                        blocks.append(
                            self._create_block_from_words_info(current_block_words_info, img_width, img_height))
                        current_block_words_info = []
                    continue

                word_info = {
                    'text': word_text_raw.strip(),
                    'left': data.get('left', [0])[i],
                    'top': data.get('top', [0])[i],
                    'width': data.get('width', [0])[i],
                    'height': data.get('height', [0])[i],
                    'font_name': '',
                    'block_num': data.get('block_num', [-1])[i]
                }

                current_word_top_y = word_info['top']
                current_word_height = word_info['height']

                prev_block_num = current_block_words_info[-1]['block_num'] if current_block_words_info else -1
                is_new_tesseract_block = (word_info['block_num'] != prev_block_num)

                vertical_gap_from_prev_word = 0
                if prev_word_bottom_y > 0:
                    vertical_gap_from_prev_word = current_word_top_y - prev_word_bottom_y

                avg_word_height_in_current_list = np.mean(
                    [w['height'] for w in current_block_words_info]) if current_block_words_info else 15
                large_gap_threshold = avg_word_height_in_current_list * 1.5

                is_large_vertical_gap = (vertical_gap_from_prev_word > large_gap_threshold)

                if (is_new_tesseract_block or is_large_vertical_gap) and current_block_words_info:
                    blocks.append(self._create_block_from_words_info(current_block_words_info, img_width, img_height))
                    current_block_words_info = []

                current_block_words_info.append(word_info)
                prev_word_bottom_y = current_word_top_y + current_word_height

            if current_block_words_info:
                blocks.append(self._create_block_from_words_info(current_block_words_info, img_width, img_height))

            return blocks

        except pytesseract.TesseractError as e:
            print(f"An OCR error occurred in OcrHandler (TesseractError): {e}.")
            traceback.print_exc()
            return []
        except Exception as e:
            print(f"An OCR error occurred in OcrHandler (General Error): {e}.")
            traceback.print_exc()
            return []

    def _create_block_from_words_info(self, words_list, img_width, img_height):
        block_text = " ".join([w['text'] for w in words_list])

        x_min = min(w['left'] for w in words_list)
        y_min = min(w['top'] for w in words_list)
        x_max = max(w['left'] + w['width'] for w in words_list)
        y_max = max(w['top'] + w['height'] for w in words_list)
        bbox = (x_min, y_min, x_max, y_max)

        font_sizes = [w['height'] for w in words_list]
        avg_font_size = statistics.mean(font_sizes) if font_sizes else 0.0

        is_bold = 0.0
        is_italic = 0.0

        x0_norm = bbox[0] / img_width if img_width > 0 else 0.0
        height_norm = (bbox[3] - bbox[1]) / img_height if img_height > 0 else 0.0

        block_center_x_norm = ((bbox[0] + bbox[2]) / 2) / img_width
        is_centered = float(abs(block_center_x_norm - 0.5) < 0.15)

        first_char = block_text.lstrip()[0] if block_text.lstrip() else ''
        has_leading_digit_or_bullet = float(
            first_char.isdigit() or first_char in ['•', '●', '☆', '-', '*'])

        return {
            'text': block_text,
            'bbox': bbox,
            'font_size': avg_font_size,
            'is_bold': is_bold,
            'is_italic': is_italic,
            'is_centered': is_centered,
            'char_count': float(len(block_text)),
            'x0_norm': x0_norm,
            'height_norm': height_norm,
            'has_leading_digit_or_bullet': has_leading_digit_or_bullet,
            'relative_font_size_to_page_avg': 0.0,
            'relative_font_size_to_page_max': 0.0,
            'line_gap_above_norm': 0.0
        }
